# -*- coding: utf-8 -*-
# encoding = gbk
#****************************************************************
# Test.py
# Author     : Vince
# Version    : 1.0
# Date       : 2011-3-10
# Description: 测试体验代码，代码测试之用
#****************************************************************
from testframe import *
import codecs
import re, sys

def NumCount(iNum, n):
    count=0;
    for i in range(1, iNum+1):
        listNum=[]
        listNum=list(str(i))
        for j in range(0, len(listNum)):
            if listNum[j]==str(n):
                count=count+1
    return count

def mytest(num):
     count=0
     for i in range(1, num+1):
         numlist=re.findall('9', str(i))
         count=count+len(numlist)
     return count
mytest(50)

def foo():
    sum = 0
    for i in range(100):
        sum += i
    print sum
    return sum

#begin =datetime.datetime.now()
#print 'begin:', begin
#mytest(5)
#print 'now:', datetime.datetime.now()
#print datetime.datetime.now()-begin
#os.mkdir('E:\\AUTOTEST\\DownLoad\\ttt\\')
#profile.run("foo()")

import unittest

class MyCase(unittest.TestCase):
    def testAdd(self):  ## test method names begin 'test*'
        self.assertEquals(foo(), 4950)
        self.assertEquals(0 + 1, 1)
    def testMultiply(self):
        self.assertEquals((0 * 10), 0)
        self.assertEquals((5 * 8), 40)

#if __name__ == '__main__':
#    unittest.main()



#conn = httplib.HTTPConnection("172.16.1.35:8080")  
#conn.request("GET", "/test/go.do?t=2")  
#rsps = conn.getresponse()
#data = rsps.read()
#conn.close()
##print data
#print rsps.status, rsps.reason 

#params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})  
#headers = {"Content-type": "application/x-www-form-urlencoded",  "Accept": "text/plain"}  
#conn1 = httplib.HTTPConnection("musi-cal.mojam.com:80")  
#conn1.request("POST", "/cgi-bin/query", params, headers)  
#response = conn1.getresponse()  
#print response.status, response.reason  
#data1 = response.read()  
#conn1.close() 

#def People ():    
    #def run ():    
        #print("I'm running!")    
        
    #def jump ():    
        #print("I'm jumping!")    
        
    #def stop ():    
        #print("I can't stop!")    
            
    #def _dispatch_ (verb):    
        #if verb == 'run': run()    
        #elif verb == 'jump': jump()    
        #elif verb == 'stop': stop()    
    #return _dispatch_  
    
#cmd=People()
#cmd('jump')

#try:
    #a=b+1
#except:
    #(ErrorType, ErrorValue, ErrorTB) = sys.exc_info()
    #print ErrorType, ErrorValue, ErrorTB
    
#else:
    #print 'noerror'

md= {'root': {'music_list': {'sort_info': [{'ring_id': {'value': '1111'}, 'ring_name': {'value': u'\u7231\u4f60\u4e00\u4e07\u5e74'}}, {'ring_id': {'value': '2222'}, 'ring_name': {'value': u'\u8377\u5858\u6708\u8272'}}], 'value': '\n    '}, 'value': '\n  '}}
#print md.keys()
#print md.items()

def get_dictvalues(dict):
    values=[]
    def findvalues(dict, values):
        try:
            keys=dict.keys()
        except:
            #列表
            for i in range(0, len(dict)):
                findvalues(dict[i], values)
        else:
            if len(keys)==0:
                values.append('_')
            else:
                for i in range(0,len(keys)):
                    if keys[i]=='value':
                        if dict['value'].strip()<>'':   #处理无关字符  ‘\n’
                            #print dict
                            values.append(dict['value'])
                    else:
                        findvalues(dict[keys[i]], values)
                        
    findvalues(dict, values)  
    return values
    
excelobj=create_excel(os.getcwd()+'\doc\mbook_server_cms_testcase.xls')
sh=excelobj.book.Worksheets(5)
sh.Cells(3,2).Interior.Color=0xffffff
sh.Cells(4, 2).Interior.Color=0xff
sh.Cells(7, 2).Interior.Color=0xffff
excelobj.close()
    
