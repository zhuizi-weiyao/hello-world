# -*- coding: utf-8 -*-
#****************************************************************
# main.py
# Author     : Vince
# Version    : 1.0
# Date       : 2011-3-16
# Description: 测试组装，用例执行入口
#****************************************************************
from testframe import *
from module1_case import *
from module2_case import *
import module1_case

#服务系统接口测试
#设置测试环境
module1_case.excelobj=create_excel(os.getcwd()+'\doc\TestDemo_testcase.xls')
module1_case.com_ipport='172.16.1.35:8080'

begin =datetime.datetime.now()
#Add testsuite begin
content_book_list_suite()
#Add other suite from here
#Add testsuite end
#profile.run("content_book_list_suite()")

print 'Total Time:', datetime.datetime.now()-begin
statisticresult(module1_case.excelobj)
module1_case.excelobj.close()
