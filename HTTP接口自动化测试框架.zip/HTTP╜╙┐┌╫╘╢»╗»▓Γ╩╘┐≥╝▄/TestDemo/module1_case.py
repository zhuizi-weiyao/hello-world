# -*- coding: utf-8 -*-
#****************************************************************
# module1_case.py
# Author     : Vince
# Version    : 1.0
# Date       : 2011-3-10
# Description: 内容服务系统测试代码
#****************************************************************
from testframe import *

STRUCTCOL=14  #结构体开始列

#content_book_list用例集
def content_book_list_suite():
    print 'Test Begin,please waiting...'
    suiteid=4   #设置测试输入Sheetindex=1
    excelobj.del_testrecord(suiteid)  #清除历史测试数据
    
    casecount=excelobj.get_ncase(suiteid)
    checklist=['resultCode', 'listid', 'name', 'total', 'from', 'size']
    structitem=['bookid', 'name', 'title', 'progress', 'words', 'authorid', 'authorName']
    
    #获取Case基本信息
    caseinfolist=get_caseinfo(excelobj, suiteid)
    
    for caseid in range(0, casecount):
        #检查是否执行该Case
        if excelobj.read_data(suiteid,excelobj.casebegin+caseid, 2)=='N':
            write_result(excelobj, suiteid, caseid, excelobj.resultcol, 'NT')
            continue #当前Case结束，继续执行下一个Case
        
        #获取测试数据
        sInput=get_input(excelobj, suiteid, caseid, caseinfolist)   
        XmlString=run_case(com_ipport, sInput)       #执行调用
        dict=get_xmlfile_dict(os.getcwd()+'\doc\Test.xml')
        
        itemdict=dict['root']
        ret1=check_item(excelobj, suiteid, caseid,itemdict, checklist, excelobj.argbegin+excelobj.argcount)
        
        structdict=dict['root']['books']['book']
        ret2=check_struct_item(excelobj, suiteid, caseid,structdict, structitem, STRUCTCOL, 2)
        write_result(excelobj, suiteid, caseid, excelobj.resultcol, ret1, ret2)
    print 'Test End!'
